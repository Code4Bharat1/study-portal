import CssExercisePlatform from "@/components/Exercise/Css";

export default function ContentDisplay(){
    return (<CssExercisePlatform></CssExercisePlatform>)
}