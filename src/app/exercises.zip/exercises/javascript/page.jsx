import JsExercisePlatform from "@/components/Exercise/Javascript";

export default function ContentDisplay(){
    return (<JsExercisePlatform></JsExercisePlatform>)
}