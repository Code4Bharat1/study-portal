// import Exercise from '@/components/Exercise/Exercise'
// import Navbar from '@/components/Navbar/Navbar'
import Exercise from "@/components/Exercise/Exercise";

import React from "react";

const page = () => {
  return (
    <>
      
      <Exercise />
    </>
  );
};

export default page;
