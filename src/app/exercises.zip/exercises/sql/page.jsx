import SqlExercisePlatform from "@/components/Exercise/Javascript";

export default function ContentDisplay(){
    return (<SqlExercisePlatform></SqlExercisePlatform>)
}