import ExpressExercisePlatform from "@/components/Exercise/Express";

export default function ContentDisplay(){
    return (<ExpressExercisePlatform></ExpressExercisePlatform>)
}