import NextJsExercisePlatform from "@/components/Exercise/Nextjs";

export default function ContentDisplay(){
    return (<NextJsExercisePlatform></NextJsExercisePlatform>)
}