import MySqlExercisePlatform from "@/components/Exercise/Javascript";

export default function ContentDisplay(){
    return (<MySqlExercisePlatform></MySqlExercisePlatform>)
}