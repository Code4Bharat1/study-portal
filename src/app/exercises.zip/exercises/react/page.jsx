import ReactExercisePlatform from "@/components/Exercise/React";

export default function ContentDisplay(){
    return (<ReactExercisePlatform></ReactExercisePlatform>)
}