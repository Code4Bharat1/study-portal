import MongoDBExercisePlatform from "@/components/Exercise/MongoDb";

export default function ContentDisplay(){
    return (<MongoDBExercisePlatform></MongoDBExercisePlatform>)
}