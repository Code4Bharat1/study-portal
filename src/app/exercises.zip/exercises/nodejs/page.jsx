import NodeJsExercisePlatform from "@/components/Exercise/Nodejs";

export default function ContentDisplay(){
    return (<NodeJsExercisePlatform></NodeJsExercisePlatform>)
}