import React from 'react'

function CustomDocument() {
  return (
    <div>CustomDocument</div>
  )
}

export default CustomDocument