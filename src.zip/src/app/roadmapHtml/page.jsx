import RoadmapHtml from '@/components/Htmlpage/RoadmapHtml'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <RoadmapHtml/>

   </>
  )
}

export default page
