import Basic from '@/components/JavaPage/Basicjava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Basic/>
   </>
  )
}

export default page