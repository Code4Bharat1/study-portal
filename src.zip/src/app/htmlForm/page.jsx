import Form from '@/components/Htmlpage/Form'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <Form/>
   </>
  )
}

export default page