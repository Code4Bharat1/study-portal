import Driver from '@/components/Mongodbpage/Driver'
import MongoDBSidebar from '@/components/Mongodbpage/MongoDBSidebar'
import React from 'react'

const page = () => {
  return (
  <>
  <MongoDBSidebar/>
  <Driver/>
  </>
  )
}

export default page