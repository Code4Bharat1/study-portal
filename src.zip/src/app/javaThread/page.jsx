import SidebarJava from '@/components/JavaPage/Sidebarjava'
import Threadjava from '@/components/JavaPage/Threadjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Threadjava/>
   </>
  )
}

export default page