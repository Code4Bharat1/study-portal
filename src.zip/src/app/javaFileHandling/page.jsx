import FileHandling from '@/components/JavaPage/FileHandling'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
    <>
    <SidebarJava/>
    <FileHandling/>
    </>
  )
}

export default page