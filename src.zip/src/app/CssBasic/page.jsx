import React from "react";
import Sidebar from "@/components/CssFullContent/cssSidebar";
import Basic from "@/components/CssFullContent/CssBasic";
export default function page() {
  return (
    <div>
      <Sidebar />
      <Basic />
    </div>
  );
}
