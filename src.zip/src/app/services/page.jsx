
import Service from "@/components/Servics/Service";
import React from "react";

const page = () => {
  return (
    <>
      
      <Service />
    </>
  );
};

export default page;
