import MongoPage from "@/components/FirstMongo/FirstMongo";

import React from "react";

const page = () => {
  return (
    <>
      
      <MongoPage />
    </>
  );
};

export default page;
