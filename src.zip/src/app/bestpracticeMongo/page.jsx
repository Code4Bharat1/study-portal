import MongoDbBestPractices from '@/components/BestPractice/MongoBestpractice'
import React from 'react'

const page = () => {
  return (
  <>
  <MongoDbBestPractices/>
  </>
  )
}

export default page