import ArrayJava from '@/components/JavaPage/ArrayJava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
    <>
    <SidebarJava/>
    <ArrayJava/>
    </>
  )
}

export default page