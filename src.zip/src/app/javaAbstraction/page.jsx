import Abstraction from '@/components/JavaPage/Abstraction'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
    <>
    <SidebarJava/>
    <Abstraction/>
    </>
  )
}

export default page