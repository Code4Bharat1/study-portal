import NodeJsBestPractice from '@/components/BestPractice/NodejsBestPractice'
import React from 'react'

const page = () => {
  return (
 <>
 <NodeJsBestPractice/>
 </>
  )
}

export default page
