import ReactPage from '@/components/Reactpage/page'
import React from 'react'

function page() {
  return (
    <ReactPage/>
  )
}

export default page