import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import Table from '@/components/Htmlpage/Table'
import React from 'react'

const page = () => {
  return (
 <>
  <Sidebarhtml/>
  <Table/>
 </>
  )
}

export default page