import Oops from '@/components/Pythonpage/Oops'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
  <>
  <Pythonsidebar/>
  <Oops/>
  </>
  )
}

export default page