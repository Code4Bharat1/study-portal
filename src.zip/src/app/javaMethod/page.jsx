import Methodjava from '@/components/JavaPage/Methodjava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Methodjava/>
   </>
  )
}

export default page