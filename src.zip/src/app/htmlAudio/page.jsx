import MediaAudio from '@/components/Htmlpage/MediaAudio'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <MediaAudio/>
   </>
  )
}

export default page