import Library from '@/components/Pythonpage/Library'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
  <>
  <Pythonsidebar/>
  <Library/>
  </>
  )
}

export default page