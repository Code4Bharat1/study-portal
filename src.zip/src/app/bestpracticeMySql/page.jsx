import MysqlBestPractices from '@/components/BestPractice/MySqlBestPractice'
import React from 'react'

const page = () => {
  return (
  <>
  <MysqlBestPractices/>
  </>
  )
}

export default page
