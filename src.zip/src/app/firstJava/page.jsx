import FirstJava from '@/components/JavaPage/FirstJava'
import React from 'react'

const page = () => {
  return (
   <>
   <FirstJava/>
   </>
  )
}

export default page