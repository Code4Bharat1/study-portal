import ReactBestpractice from '@/components/BestPractice/ReactBestpractice'
import React from 'react'

const page = () => {
  return (
   <>
   <ReactBestpractice/>
   </>
  )
}

export default page