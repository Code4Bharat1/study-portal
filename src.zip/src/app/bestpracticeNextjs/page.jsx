import NextBestPractices from '@/components/BestPractice/NextjsBestpractice'
import React from 'react'

const page = () => {
  return (
  <>
  <NextBestPractices/>
  </>
  )
}

export default page