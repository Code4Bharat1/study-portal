import JavaBestpractice from '@/components/BestPractice/JavaBestpractice'
import React from 'react'

const page = () => {
  return (
    <>
    <JavaBestpractice/>
    </>
  )
}

export default page
