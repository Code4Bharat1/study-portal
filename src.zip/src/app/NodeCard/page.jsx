import React from "react";
//import Navbar from '@/component/Navbar'
import Card from "@/components/fullnodecontent/CardNode";

export default function page() {
  return (
    <div>
      

      <div className="mt-25">
        <Card />
      </div>
    </div>
  );
}
