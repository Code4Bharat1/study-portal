import ControlStatementJava from '@/components/JavaPage/ControlStatementJava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <ControlStatementJava/>
   </>   
  )
}

export default page