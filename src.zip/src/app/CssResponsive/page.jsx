import React from "react";
import Sidebar from "@/components/CssFullContent/cssSidebar";

import Responsive from "@/components/CssFullContent/CssResponsive";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <Responsive />
    </div>
  );
}
