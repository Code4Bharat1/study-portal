import Activity from '@/components/Activity/Activity'
import React from 'react'

function page() {
  return (
   <Activity/>
  )
}

export default page