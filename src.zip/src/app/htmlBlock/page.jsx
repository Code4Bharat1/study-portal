import Blockinline from '@/components/Htmlpage/Blockinline'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <Blockinline/>
   </>
  )
}

export default page