import Basichtml from '@/components/Htmlpage/Basichtml'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <Basichtml/>
   </>
  )
}

export default page