import MySQLSidebar from '@/components/Mysql/MySQLSidebar'
import MySQLUpdate from '@/components/Mysql/MySQLUpdate'
import React from 'react'

const page = () => {
  return (
   <>
   <MySQLSidebar/>
   <MySQLUpdate/>
   </>
  )
}

export default page
