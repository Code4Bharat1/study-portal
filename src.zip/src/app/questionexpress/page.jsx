import QuestionExpress from '@/components/QuestionMongo/QuestionExpress'

import React from 'react'

const page = () => {
  return (
    <>
    <QuestionExpress/>
    </>
  )
}

export default page