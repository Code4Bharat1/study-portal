import HtmlHome from '@/components/Htmlpage/HtmlHome'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <HtmlHome/>
   </>
  )
}

export default page