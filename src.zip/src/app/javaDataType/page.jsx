import Datatypejava from '@/components/JavaPage/Datatypejava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Datatypejava/>
   </>
  )
}

export default page