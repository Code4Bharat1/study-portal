import HtmlExercisePlatform from "@/components/Exercise/Html";

export default function ContentDisplay(){
    return (<HtmlExercisePlatform></HtmlExercisePlatform>)
}