import QuestionMongo from '@/components/QuestionMongo/QuestionMongo'
import React from 'react'

const page = () => {
  return (
   <>
   <QuestionMongo/>
   </>
  )
}

export default page