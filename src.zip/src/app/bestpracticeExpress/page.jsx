import ExpressBestPractices from '@/components/BestPractice/ExpressBestPractice'
import React from 'react'

const page = () => {
  return (
   <>
   <ExpressBestPractices/>
   </>
  )
}

export default page