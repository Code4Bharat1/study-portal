import HomeJava from '@/components/JavaPage/HomeJava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <HomeJava/>
   </>
  )
}

export default page