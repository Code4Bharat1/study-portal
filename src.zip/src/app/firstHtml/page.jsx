import Firsthtml from '@/components/Htmlpage/Firsthtml'
import React from 'react'

const page = () => {
  return (
  <>
  <Firsthtml/>
  </>
  )
}

export default page