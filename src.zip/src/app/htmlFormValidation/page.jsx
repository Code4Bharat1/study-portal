import Formvalidation from '@/components/Htmlpage/Formvalidation'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
    <>
    <Sidebarhtml/>
    <Formvalidation/>
    </>
  )
}

export default page