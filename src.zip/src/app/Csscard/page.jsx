import React from 'react'
import Card from '@/components/CssFullContent/CssCard'
export default function page() {
  return (
    <div>
        <Card/>
      
    </div>
  )
}
