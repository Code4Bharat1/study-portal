import QuestionReact from '@/components/QuestionMongo/QuestionReact'
import React from 'react'

const page = () => {
  return (
  <>
  <QuestionReact/>
  </>
  )
}

export default page