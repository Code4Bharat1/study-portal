//import Express from '@/components/Expresspage/Expresspage'
import PHPPage from '@/components/Phppage/Phppage'
import React from 'react'

function page() {
  return (
    <PHPPage/>
  )
}

export default page