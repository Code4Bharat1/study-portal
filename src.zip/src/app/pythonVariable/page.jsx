import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import Variable from '@/components/Pythonpage/Variable'
import React from 'react'

const page = () => {
  return (
   <>
   <Pythonsidebar/>
   <Variable/>
   </>
  )
}

export default page