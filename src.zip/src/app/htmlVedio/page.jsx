import MediaVedio from '@/components/Htmlpage/MediaVedio'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <MediaVedio/>
   </>
  )
}

export default page