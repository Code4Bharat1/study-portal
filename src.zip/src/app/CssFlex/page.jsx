import React from "react";
import Sidebar from "@/components/CssFullContent/cssSidebar";

import Flex from "@/components/CssFullContent/CssFlex";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <Flex />
    </div>
  );
}
