import FirstPython from '@/components/Pythonpage/FirstPython'
import React from 'react'

const page = () => {
  return (
  <>
  <FirstPython/>
  </>
  )
}

export default page