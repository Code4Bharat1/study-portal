import SidebarJava from '@/components/JavaPage/Sidebarjava'
import StringJava from '@/components/JavaPage/StringJava'
import React from 'react'

const page = () => {
  return (
  <>
  <SidebarJava/>
  <StringJava/>
  </>
  )
}

export default page
