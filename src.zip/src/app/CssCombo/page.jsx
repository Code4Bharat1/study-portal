import React from "react";
import Sidebar from "@/components/CssFullContent/cssSidebar";
import Combo from "@/components/CssFullContent/CssCombination";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <Combo />
    </div>
  );
}
