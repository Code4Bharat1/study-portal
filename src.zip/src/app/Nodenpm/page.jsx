
import Sidebar from "@/components/fullnodecontent/nodesidebar";
import React from "react";
import Npm from "@/components/fullnodecontent/npmnode";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <Npm />
    </div>
  );
}
