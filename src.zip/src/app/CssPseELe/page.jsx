import React from "react";
import Sidebar from "@/components/CssFullContent/cssSidebar";

import Pseudoele from "@/components/CssFullContent/CssPseudoEle";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <Pseudoele />
    </div>
  );
}
