import PythonBestPractice from '@/components/BestPractice/PythonBestPractice'
import React from 'react'

const page = () => {
  return (
   <>
   <PythonBestPractice/>
   </>
  )
}

export default page
