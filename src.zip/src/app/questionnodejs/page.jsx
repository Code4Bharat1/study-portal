import QuestionNode from '@/components/QuestionMongo/QuestionNode'
import React from 'react'

const page = () => {
  return (
    <>
    <QuestionNode/>
    </>
  )
}

export default page