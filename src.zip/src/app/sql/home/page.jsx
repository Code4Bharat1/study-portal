import React from "react";
import Sidebar from "@/components/Sql/Sidebar";

import SQLHome from "@/components/Sql/Home.jsx";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <SQLHome />
    </div>
  );
}
