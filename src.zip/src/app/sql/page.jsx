import React from "react";

import Card from "@/components/Sql/Card";

export default function page() {
  return (
    <div>
      
      {/* <Sidebar/> */}
      <Card />
    </div>
  );
}
