import Aggrationgroupstage from '@/components/Mongodbpage/Aggrationgroupstage'
import MongoDBSidebar from '@/components/Mongodbpage/MongoDBSidebar'
import React from 'react'

const page = () => {
  return (
   <>
   <MongoDBSidebar/>
   <Aggrationgroupstage/>
   </>
  )
}

export default page