import SqlbestPractice from '@/components/BestPractice/SqlBestpractice'
import React from 'react'

const page = () => {
  return (
  <>
  <SqlbestPractice/>
  
  </>
  )
}

export default page
