import Polymorphism from '@/components/JavaPage/Polymorphism'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Polymorphism/>
   </>
  )
}

export default page