import Loopjava from '@/components/JavaPage/Loopjava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
    <>
    <SidebarJava/>
    <Loopjava/>
    </>
  )
}

export default page
