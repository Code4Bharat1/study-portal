

import CssBestPractice from '@/components/BestPractice/CssBestPractice'
import React from 'react'

const page = () => {
  return (
   <>
  <CssBestPractice/>
   </>
  )
}

export default page
