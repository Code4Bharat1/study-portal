import Express from '@/components/Expresspage/Expresspage'
import React from 'react'

function page() {
  return (
    <Express/>
  )
}

export default page