import BestPractices from '@/components/BestPractice/BestPracticecard'
import React from 'react'

const page = () => {
  return (
   <>
   <BestPractices/>
   </>
  )
}

export default page