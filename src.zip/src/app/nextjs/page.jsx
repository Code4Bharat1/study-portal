
import NextJsPage from '@/components/Nextjs/Nextpage'
import React from 'react'

function page() {
  return (
   <NextJsPage/>
  )
}

export default page