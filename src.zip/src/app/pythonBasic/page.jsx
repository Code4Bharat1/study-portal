import BasicPython from '@/components/Pythonpage/BasicPython'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
  <>
  <Pythonsidebar/>
  <BasicPython/>
  </>
  )
}

export default page