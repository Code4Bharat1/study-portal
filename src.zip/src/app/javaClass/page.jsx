import ClassObjectJava from '@/components/JavaPage/ClassObjectJava'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <ClassObjectJava/>
   </>
  )
}

export default page