import Datatype from '@/components/Pythonpage/Datatype'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
 <>
 <Pythonsidebar/>
 <Datatype/>
 </>
  )
}

export default page