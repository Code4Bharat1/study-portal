import HtmlBestPractices from '@/components/BestPractice/Htmlbestpractice'
import React from 'react'

const page = () => {
  return (
   <>
   <HtmlBestPractices/>
   </>
  )
}

export default page