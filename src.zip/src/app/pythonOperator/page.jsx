import Operator from '@/components/Pythonpage/Operator'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
  <>
  <Pythonsidebar/>
  <Operator/>
  </>
  )
}

export default page