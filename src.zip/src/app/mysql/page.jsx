import MySQLPage from '@/components/Mysql/Mysql'
import React from 'react'

const page = () => {
  return (
  <>
  <MySQLPage/>
  </>
  )
}

export default page