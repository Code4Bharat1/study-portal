import Encapsulation from '@/components/JavaPage/Encapsulation'
import SidebarJava from '@/components/JavaPage/Sidebarjava'
import React from 'react'

const page = () => {
  return (
   <>
   <SidebarJava/>
   <Encapsulation/>
   </>
  )
}

export default page