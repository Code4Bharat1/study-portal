import Attribute from '@/components/Htmlpage/Attribute'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <Attribute/>
   </>
  )
}

export default page