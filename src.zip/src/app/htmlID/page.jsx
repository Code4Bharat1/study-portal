import IdClass from '@/components/Htmlpage/IdClass'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <IdClass/>
   </>
  )
}

export default page
