import Heading from '@/components/Htmlpage/Heading'
import Sidebarhtml from '@/components/Htmlpage/Sidebarhtml'
import React from 'react'

const page = () => {
  return (
   <>
   <Sidebarhtml/>
   <Heading/>
   </>
  )
}

export default page