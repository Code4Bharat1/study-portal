
import Sidebar from "@/components/fullnodecontent/nodesidebar";
import React from "react";
import File from "@/components/fullnodecontent/fsnode";
export default function page() {
  return (
    <div>
      
      <Sidebar />
      <File />
    </div>
  );
}
