import Controlflow from '@/components/Pythonpage/Controlflow'
import Pythonsidebar from '@/components/Pythonpage/Pythonsidebar'
import React from 'react'

const page = () => {
  return (
   <>
   <Pythonsidebar/>
   <Controlflow/>
   </>
  )
}

export default page