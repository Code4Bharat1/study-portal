//import MongoDBSidebar from '@/components/Mongodbpage/MongoDBSidebar'
//import Validation from '@/components/Mongodbpage/Validation'
import MongoDBSidebar from '@/components/Mongodbpage/MongoDBSidebar'
import Validation from '@/components/Mongodbpage/Validation'
import React from 'react'

const page = () => {
  return (
  <>
  <MongoDBSidebar/>
  <Validation/>
  </>
  )
}

export default page
